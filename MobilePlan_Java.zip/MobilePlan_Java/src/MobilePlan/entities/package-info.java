/**
 * the entities package
 */

package MobilePlan.entities;