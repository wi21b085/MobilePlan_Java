/**
 * the util package
 */

package MobilePlan.util;