package MobilePlan.provided;

public enum ConnectionType {
    STANDARD, PREMIUM, TEXT;
}
